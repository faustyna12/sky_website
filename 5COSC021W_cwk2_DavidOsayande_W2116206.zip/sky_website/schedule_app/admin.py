from django.contrib import admin
from .models import Meeting, Team, MeetingParticipant


class MeetingParticipantInline(admin.TabularInline):
    model = MeetingParticipant
    extra = 1  # allows adding one extra blank participant row in admin


class MeetingAdmin(admin.ModelAdmin):
    list_display = ('title', 'date', 'start_time', 'organiser', 'team', 'cancelled')
    list_filter = ('date', 'team', 'cancelled')
    search_fields = ('title', 'description')
    inlines = [MeetingParticipantInline]


# Register models in Django admin panel
admin.site.register(Meeting, MeetingAdmin)
admin.site.register(Team)