from django.urls import path
from .views import schedule_view, cancel_meeting, edit_meeting

urlpatterns = [
    path('', schedule_view, name='schedule'),  # homepage FIX
    path('edit/<int:meeting_id>/', edit_meeting, name='edit_meeting'),
    path('cancel/<int:meeting_id>/', cancel_meeting, name='cancel_meeting'),
]