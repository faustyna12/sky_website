from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from .models import Meeting
from .forms import MeetingForm
from datetime import timedelta
from calendar import monthrange


def schedule_view(request):
    today = timezone.now().date()

    # -------------------------
    # HANDLE FORM SUBMISSION
    # -------------------------
    if request.method == "POST":
        form = MeetingForm(request.POST)

        if form.is_valid():
            date = form.cleaned_data['date']
            start_time = form.cleaned_data['start_time']
            end_time = form.cleaned_data['end_time']

            # check for overlapping meetings
            existing = Meeting.objects.filter(
                date=date,
                start_time__lt=end_time,
                end_time__gt=start_time,
                cancelled=False
            )

            if existing.exists():
                form.add_error(None, "This time slot is already booked.")
            else:
                form.save()
                return redirect('schedule')
    else:
        form = MeetingForm()

    # -------------------------
    # FILTER + SORT DATA
    # -------------------------
    today_meetings = Meeting.objects.filter(
        date=today,
        cancelled=False
    ).order_by('start_time')

    upcoming_meetings = Meeting.objects.filter(
        date__gt=today,
        cancelled=False
    ).order_by('date', 'start_time')[:5]

    week_end = today + timedelta(days=7)

    this_week = Meeting.objects.filter(
        date__range=[today, week_end],
        cancelled=False
    ).order_by('date', 'start_time')

    # -------------------------
    # MONTHLY VIEW
    # -------------------------
    current_year = today.year
    current_month = today.month

    month_start = today.replace(day=1)
    month_end = today.replace(day=monthrange(current_year, current_month)[1])

    monthly_meetings = Meeting.objects.filter(
        date__range=[month_start, month_end],
        cancelled=False
    ).order_by('date', 'start_time')

    all_meetings = Meeting.objects.filter(
        cancelled=False
    ).order_by('date', 'start_time')

    # -------------------------
    # CONTEXT
    # -------------------------
    context = {
        'form': form,
        'today': today,
        'today_meetings': today_meetings,
        'upcoming_meetings': upcoming_meetings,
        'this_week': this_week,
        'monthly_meetings': monthly_meetings,
        'all_meetings': all_meetings,
    }

    return render(request, 'schedule_app/schedule.html', context)


# -------------------------
# CANCEL MEETING
# -------------------------
def cancel_meeting(request, meeting_id):
    meeting = get_object_or_404(Meeting, id=meeting_id)
    meeting.cancelled = True
    meeting.save()
    return redirect('schedule')


# -------------------------
# EDIT MEETING
# -------------------------
def edit_meeting(request, meeting_id):
    meeting = get_object_or_404(Meeting, id=meeting_id)

    if request.method == "POST":
        form = MeetingForm(request.POST, instance=meeting)
        if form.is_valid():
            form.save()
            return redirect('schedule')
    else:
        form = MeetingForm(instance=meeting)

    return render(request, 'schedule_app/editmeeting.html', {'form': form})