from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User
from .models import Meeting, Team
from datetime import date, time


class ScheduleTests(TestCase):

    def setUp(self):
        # create test user (required for organiser FK)
        self.user = User.objects.create_user(
            username="testuser",
            password="testpass"
        )

        # create test team
        self.team = Team.objects.create(name="Test Team")

        # create a test meeting
        self.meeting = Meeting.objects.create(
            title="Test Meeting",
            description="Test Description",
            organiser=self.user,
            team=self.team,
            date=date.today(),
            start_time=time(10, 0),
            end_time=time(11, 0),
            platform="Zoom",
            meeting_link="https://zoom.us/test",
            cancelled=False
        )

    def test_schedule_page_loads(self):
        response = self.client.get(reverse('schedule'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'schedule.html')

    def test_create_meeting(self):
        response = self.client.post(reverse('schedule'), {
            'title': 'New Meeting',
            'description': 'Test',
            'date': date.today(),
            'start_time': '12:00',
            'end_time': '13:00',
            'platform': 'Zoom',
            'meeting_link': 'https://zoom.us/test'
        })

        self.assertEqual(response.status_code, 302)
        self.assertEqual(Meeting.objects.count(), 2)

    def test_prevent_overlapping_meeting(self):
        response = self.client.post(reverse('schedule'), {
            'title': 'Overlap Meeting',
            'date': date.today(),
            'start_time': '10:30',
            'end_time': '11:30',
            'platform': 'Zoom'
        })

        self.assertEqual(Meeting.objects.count(), 1)
        self.assertContains(response, "already booked")

    def test_cancel_meeting(self):
        response = self.client.get(
            reverse('cancel_meeting', args=[self.meeting.id])
        )

        self.meeting.refresh_from_db()

        self.assertTrue(self.meeting.cancelled)
        self.assertEqual(response.status_code, 302)

    def test_edit_meeting(self):
        response = self.client.post(
            reverse('edit_meeting', args=[self.meeting.id]),
            {
                'title': 'Updated Meeting',
                'date': date.today(),
                'start_time': '14:00',
                'end_time': '15:00',
                'platform': 'Zoom'
            }
        )

        self.meeting.refresh_from_db()

        self.assertEqual(str(self.meeting.start_time), "14:00:00")
        self.assertEqual(response.status_code, 302)

    def test_meetings_are_ordered(self):
        Meeting.objects.create(
            title="Earlier Meeting",
            organiser=self.user,
            team=self.team,
            date=date.today(),
            start_time=time(9, 0),
            end_time=time(10, 0),
            platform="Zoom",
            cancelled=False
        )

        response = self.client.get(reverse('schedule'))
        meetings = response.context['today_meetings']

        self.assertLessEqual(
            meetings[0].start_time,
            meetings[1].start_time
        )