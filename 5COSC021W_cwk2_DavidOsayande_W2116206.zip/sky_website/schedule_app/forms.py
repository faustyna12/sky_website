from django import forms
from .models import Meeting


class MeetingForm(forms.ModelForm):
    class Meta:
        model = Meeting
        fields = [
            'title',
            'description',
            'organiser',
            'team',
            'date',
            'start_time',
            'end_time',
            'platform',
            'meeting_link'
        ]