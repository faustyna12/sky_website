from django.db import models
from django.contrib.auth.models import User


# -------------------------
# Team Model
# -------------------------
class Team(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


# -------------------------
# Meeting Model
# -------------------------
class Meeting(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)

    organiser = models.ForeignKey(User, on_delete=models.CASCADE)
    team = models.ForeignKey(Team, on_delete=models.CASCADE, null=True, blank=True)

    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()

    PLATFORM_CHOICES = [
        ('Zoom', 'Zoom'),
        ('Teams', 'Microsoft Teams'),
        ('Meet', 'Google Meet'),
        ('Other', 'Other'),
    ]

    platform = models.CharField(max_length=20, choices=PLATFORM_CHOICES)
    meeting_link = models.URLField(blank=True)

    cancelled = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.title} - {self.date}"


# -------------------------
# Meeting Participant Model
# -------------------------
class MeetingParticipant(models.Model):
    meeting = models.ForeignKey(
        Meeting,
        on_delete=models.CASCADE,
        related_name='participants'
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    joined_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} in {self.meeting.title}"